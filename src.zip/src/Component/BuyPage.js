import React from "react";
import Navbar from "./Navbar";
function BuyPage(){
return(
    <div>
        <Navbar/>
        Buy

        
    </div>
)
}
 
export default BuyPage