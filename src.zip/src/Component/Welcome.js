import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import MainNavbar from "./MainNavbar";
import ChatBotPharmaEasy from "./ChatBot";
import { useNavigate } from "react-router-dom";

const Welcome = () => {
    const navigate =useNavigate();
    const handleLoginClick = () => {
        navigate("/UserLogin")
    }
    const carouselSettings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
    };



    return (
       
        <div>
            <MainNavbar />
            <ChatBotPharmaEasy/>
            <br/>
            <br/> 
            <h1 className="text-xl font-bold mb-4 text-center">Pharma-Easy "Where Good Health Meets Convenience"</h1>
            <br/>
            
            {/* login drop-down is not working so i addded these  */}
             {/* try h1 or p for tommorrow and add images for it and   */}
             {/* products should be side by side and replace What Our Customers Say 
              to any other  */}
            <br/>
            
            <div className="relative h-96">
                <img
                    src="https://img.freepik.com/premium-photo/businessman-holding-smartphone-blue-cross_150455-2657.jpg?size=626&ext=jpg&ga=GA1.1.40795630.1700712467&semt=ais"
                    alt="Pharmacy Quote"
                    className="w-full h-full object-cover"
                />
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-center">
                    <h1 className="text-4xl font-extrabold mb-4">
                        "Your Health is Our Priority"
                    </h1>
                    <p className="text-lg">
                        Get your medications and other essentials delivered to your doorstep!
                    </p>
                </div>
            </div>

            {/* Carousel Section */}
            <section className="mt-8">
                <Slider {...carouselSettings}>
                    <div>
                        <img
                            src="https://storage-prtl-co.imgix.net/endor/articles/2807/images/1592226476_volodymyr-hryshchenko-e8yfkjn2czy-unsplash_c.jpg"
                            alt="Carousel Image 1"
                            className="w-full h-64 object-cover"
                        />
                    </div>
                    <div>
                        <img
                            src="https://img.freepik.com/premium-vector/human-hand-holding-mobile-phone-medicine-online-payment-home-delivery-pharmacy-service-paper-bag-with-pills-bottle-medicines-drugs-thermometer-inside-medical-assistance-health-care-concept_458444-146.jpg?size=626&ext=jpg&ga=GA1.1.40795630.1700712467&semt=ais"
                            alt="Carousel Image 2"
                            className="w-full h-64 object-cover"
                        />
                    </div>
                    <div>
                        <img
                            src="https://img.freepik.com/premium-photo/mini-shopping-cart-full-homeopathic-remedies-laptop-background-homeopathy-internet-online-shopping-concept_253401-1733.jpg?size=626&ext=jpg&ga=GA1.1.40795630.1700712467&semt=ais"
                            alt="Carousel Image 3"
                            className="w-full h-64 object-cover"
                        />
                    </div>
                </Slider>
            </section>

            {/* Featured Products Section */}
            <section className="mt-8">
                <h2 className="text-3xl font-extrabold text-center mb-6">
                    Featured Products
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <div className="bg-white p-4 rounded-md shadow-md">
                        <img
                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3o3ng_uTMS9TdKvAt-E5P_Pms0X3yX6ya5w&usqp=CAU"
                            alt="Product 1"
                            className="w-full h-30 object-cover mb-4 rounded-md"
                        />
                        <br/>
                        <br/>
                        <br/>
                        <h3 className="text-xl font-semibold mb-2">
                            Dolo
                        </h3>
                        <p className="text-gray-700 mb-4">
                            For the cure of Viral Fever and Temparature Increase 
                        </p>
                        <p className="text-blue-500 font-semibold">Rs:500</p>
                        <button 
                        onClick={handleLoginClick}
                            className="bg-blue-500 text-white px-4 py-2 rounded-md mt-2">
                            Buy Now
                        </button>
                    </div>
                    
                    <div className="bg-white p-4 rounded-md shadow-md">
                        <img
                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzNtXeqz-cFvaSv3O8LWVjn5GYLRgAoBgFHQ&usqp=CAU"
                            alt="Product 1"
                            className="w-full h-29s object-cover mb-4 rounded-md"
                        />
                        <h3 className="text-xl font-semibold mb-2">
                            Cheston
                        </h3>
                        <p className="text-gray-700 mb-4">
                            For the cure of severe cough and cold 
                        </p>
                        
                        <p className="text-blue-500 font-semibold">Rs:500</p>
                        <button 
                        onClick={handleLoginClick}
                            className="bg-blue-500 text-white px-4 py-2 rounded-md mt-2">
                            Buy Now
                        </button>
                    </div>
                    
                    <div className="bg-white p-4 rounded-md shadow-md">
                        <img
                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRa3GF2Ve88yfqag8gLsOWXinGr2ZBelgstkA&usqp=CAU"
                            alt="Product 1"
                            className="w-full h-29 object-cover mb-4 rounded-md"
                        />
                        <h3 className="text-xl font-semibold mb-2">
                            Aspirine
                        </h3>
                        <p className="text-gray-700 mb-4">
                            Basic and Severe Pain Reliever
                        </p>
                        <p className="text-blue-500 font-semibold">Rs:500</p>
                        <button 
                        onClick={handleLoginClick}
                            className="bg-blue-500 text-white px-4 py-2 rounded-md mt-2">
                            Buy Now
                        </button>
                    </div>
                    
                    {/* Add more featured product cards as needed */}
                </div>
                
            </section>

            {/* Our Services Section */}
            <section className="mt-8">
                <h2 className="text-3xl font-extrabold text-center mb-6">
                    Our Services
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <div className="bg-white p-4 rounded-md shadow-md">
                        <h3 className="text-xl font-semibold mb-2">
                            Prescription Refills
                        </h3>
                        <p className="text-gray-700 mb-4">
                            Easily refill your prescriptions online.
                        </p>
                        <button className="bg-blue-500 text-white px-4 py-2 rounded-md mt-2">
                            Learn More
                        </button>
                    </div>

                    <div className="bg-white p-4 rounded-md shadow-md">
                        <h3 className="text-xl font-semibold mb-2">
                            Health Consultations
                        </h3>
                        <p className="text-gray-700 mb-4">
                            Schedule virtual health consultations with our experts.
                        </p>
                        <button className="bg-blue-500 text-white px-4 py-2 rounded-md mt-2">
                            Learn More
                        </button>
                    </div>

                    <div className="bg-white p-4 rounded-md shadow-md">
                        <h3 className="text-xl font-semibold mb-2">
                            Wellness Workshops
                        </h3>
                        <p className="text-gray-700 mb-4">
                            Join our workshops for a healthier lifestyle.
                        </p>
                        <button className="bg-blue-500 text-white px-4 py-2 rounded-md mt-2">
                            Learn More
                        </button>
                    </div>
                </div>
            </section>

            {/* Additional sections */}
            {/* ... (any other sections you want to add) */}
            <section className="mt-8">
                <h2 className="text-3xl font-extrabold text-center mb-6">
                    What Our Customers Say
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <div className="bg-white p-4 rounded-md shadow-md">
                        <p className="text-gray-700 mb-4">
                            "I had a fantastic experience with this service! The quick delivery and quality products exceeded my expectations. PharmaEasy is now my go-to for all my medical needs."
                        </p>
                        <p className="font-semibold">- Customer 1</p>
                    </div>

                    <div className="bg-white p-4 rounded-md shadow-md">
                        <p className="text-gray-700 mb-4">
                            "PharmaEasy has made getting my medications hassle-free. The user-friendly website and prompt customer service make it a reliable choice. I highly recommend it to everyone."
                        </p>
                        <p className="font-semibold">- Customer 2</p>
                    </div>

                    <div className="bg-white p-4 rounded-md shadow-md">
                        <p className="text-gray-700 mb-4">
                            "Exceptional service! The variety of products and brands available on PharmaEasy is impressive. The convenience of ordering online and having everything delivered to my doorstep makes my life so much easier. Thank you, PharmaEasy!"
                        </p>
                        <p className="font-semibold">- Customer 3</p>
                    </div>
                </div>
            </section>

            {/* Contact Us Section */}
            <section className="mt-8">
                <h2 className="text-3xl font-extrabold text-center mb-6">Contact Us</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <div className="bg-white p-4 rounded-md shadow-md">
                        <h3 className="text-xl font-semibold mb-2">Visit Us</h3>
                        <p className="text-gray-700 mb-4">
                            123 Pharmacy Street, Cityville, State, 12345
                        </p>
                    </div>

                    <div className="bg-white p-4 rounded-md shadow-md">
                        <h3 className="text-xl font-semibold mb-2">Call Us</h3>
                        <p className="text-gray-700 mb-4">Phone: (123) 456-7890</p>
                    </div>

                    <div className="bg-white p-4 rounded-md shadow-md">
                        <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                        <p className="text-gray-700 mb-4">info@examplepharmacy.com</p>
                    </div>
                </div>
            </section>

            {/* Footer Section */}
            <footer className="mt-8 bg-green-800 text-white p-4">
                <div className="container mx-auto text-center">
                    <p>&copy; 2023 Pharmacy Easy. All rights reserved.</p>
                </div>
            </footer>
        </div>
        



    )
}

export default Welcome