import React from "react";
import Navbar from "./Navbar";
function Order(){
return(
    <div>
        <Navbar/>
        Order
    </div>
)
}
 
export default Order