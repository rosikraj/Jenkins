import React from "react";
import Navbar3 from "./Navbar3";
function Vendors(){
return(
    <div >
        <Navbar3/>
        Vendors
    </div>
)
}
 
export default Vendors;