import React from "react";
import Navbar3 from "./Navbar3";
function Requests(){
return(
    <div >
        <Navbar3/>
        Requests 
    </div>
)
}
 
export default Requests;