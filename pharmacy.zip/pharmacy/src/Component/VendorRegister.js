import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const VendorRegister = () => {
  let navigate = useNavigate();

  // State for Vendor
  const [vendor, setVendor] = useState({
    First_name: "",
    Last_name: "",
    Email: "",
    Phno: "",
    User_Id:"",
    Product_Id: "",
    License: "",
    Certificate: "",
    Password: "",
    Confirm_Password: "",
  });

  // State for Vendor errors
  const [vendorErrors, setVendorErrors] = useState({
    First_name: "",
    Last_name: "",
    Email: "",
    Phno: "",
    Product_Id: "",
    User_Id:"",
    License: "",
    Certificate: "",
    Password: "",
    Confirm_Password: "",
  });

  // State for success message
  const [successMessage, setSuccessMessage] = useState("");

  // State for error message
  const [errorMessage, setErrorMessage] = useState("");

  const validateVendor = () => {
    const errors = {};

    //  validations 
    if (!vendor.First_name.trim()) {
      errors.First_name = "First Name is required";
    }
    if (!vendor.Last_name.trim()) {
      errors.Last_name = "Last Name is required";
    }


    if (!vendor.Email.trim()) {
      errors.Email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(vendor.Email)) {
      errors.Email = "Invalid email format";
    }

    if (!vendor.Phno.trim()) {
      errors.Phno = "Mobile is required";
    } else if (!/^\d{10}$/.test(vendor.Phno)) {
      errors.Phno = "Invalid mobile number";
    }

    if (!vendor.Product_Id.trim()) {
      errors.Product_Id = "Product Id is required";
    }

    if (!vendor.User_Id.trim()) {
      errors.User_Id = "User Id is required";
    }

    if (!vendor.License.trim()) {
      errors.License = "License is required";
    }

    if (!vendor.Certificate.trim()) {
      errors.Certificate = "Certificate is required";
    }
    if (!vendor.Password.trim()) {
      errors.Password = "Password is required";
    } else if (!/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/.test(vendor.Password)) {
      errors.Password =
        "Password must contain at least 8 characters, including at least one letter, one number, and one special character";
    }
  
    if (!vendor.Confirm_Password.trim()) {
      errors.Confirm_Password = "Confirm Password is required";
    } else if (vendor.Password !== vendor.Confirm_Password) {
      errors.Confirm_Password = "Passwords do not match";
    }

    setVendorErrors(errors);

    return Object.keys(errors).length === 0;
  };

  const onInputChange = (e) => {
    setVendor({ ...vendor, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    // Validate vendor data
    const isValid = validateVendor();

    if (isValid) {
      try {
         // API endpoint for customer registration
                const response = await axios.post("http://localhost:8080/vendor", vendor);

                // Check if the 'data' property exists before accessing it
                const responseData = response && response.data;

                // Set success message
                setSuccessMessage("Registration successful");

        // Clear the form and errors
        setVendor({
          First_name: "",
          Last_name: "",
          Email: "",
          Phno: "",
          Product_Id: "",
          User_Id:"",
          License: "",
          Certificate: "",
          Password: "",
          Confirm_Password: "",
        });
        setVendorErrors({});
        setErrorMessage(""); // Clear  previous error messages

        // Redirect or handle success 
        navigate("/login");
      } catch (error) {
        console.error("Error during registration:", error.response.data);

        // Set error message
        setErrorMessage("Error during registration. Please try again.");

        // Clear success message
        setSuccessMessage("");
      }
    }
  };

  return (
    <section className="bg-white dark:bg-gray-900">
      <form onSubmit={onSubmit} className="mt-6">
        <div className="flex-1">
          <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">First Name</label>
          <input
            type="text"
            placeholder="Enter your First Name"
            className="block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40"
            name="First_name"
            value={vendor.First_name}
            onChange={onInputChange}
          />
          <span className="text-red-500">{vendorErrors.First_name}</span>
        </div>
        <div className="flex-1">
          <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">Last Name</label>
          <input
            type="text"
            placeholder="Enter your Last Name"
            className="block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40"
            name="Last_name"
            value={vendor.Last_name}
            onChange={onInputChange}
          />
          <span className="text-red-500">{vendorErrors.Last_name}</span>
        </div>
        <div className="flex-1 mt-6">
          <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">Email</label>
          <input
            type="email"
            placeholder="Enter your email"
            className="block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40"
            name="Email"
            value={vendor.Email}
            onChange={onInputChange}
          />
          <span className="text-red-500">{vendorErrors.Email}</span>
        </div>
        <div className="flex-1 mt-6">
          <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">Mobile</label>
          <input
            type="text"
            placeholder="Enter your mobile number"
            className="block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40"
            name="Phno"
            value={vendor.Phno}
            onChange={onInputChange}
          />
          <span className="text-red-500">{vendorErrors.Phno}</span>
        </div>
        <div className="flex-1 mt-6">
          <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">User Id</label>
          <input
            type="number"
            placeholder="Enter your User Id"
            className="block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40"
            name="User_Id"
            value={vendor.User_Id}
            onChange={onInputChange}
          />
          <span className="text-red-500">{vendorErrors.User_Id}</span>
        </div>
        <div className="flex-1 mt-6">
          <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">Product Id</label>
          <input
            type="number"
            placeholder="Enter your Product Id"
            className="block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40"
            name="Product_Id"
            value={vendor.Product_Id}
            onChange={onInputChange}
          />
          <span className="text-red-500">{vendorErrors.Product_Id}</span>
        </div>
        <div className="flex-1 mt-6">
          <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">License</label>
          <input
            type="text"
            placeholder="Enter your license information"
            className="block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40"
            name="License"
            value={vendor.License}
            onChange={onInputChange}
          />
          <span className="text-red-500">{vendorErrors.License}</span>
        </div>
        <div className="flex-1 mt-6">
          <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">Certificate</label>
          <input
            type="text"
            placeholder="Enter your certificate information"
            className="block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40"
            name="Certificate"
            value={vendor.Certificate}
            onChange={onInputChange}
          />
          <span className="text-red-500">{vendorErrors.Certificate}</span>
        </div>
        <div className="flex-1 mt-6">
          <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">Password</label>
          <input
            type="password"
            placeholder="Enter your password"
            className="block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40"
            name="Password"
            value={vendor.Password}
            onChange={onInputChange}
          />
          <span className="text-red-500">{vendorErrors.Password}</span>
        </div>
        <div className="flex-1 mt-6">
          <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">Confirm Password</label>
          <input
            type="password"
            placeholder="Enter your confirm password"
            className="block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40"
            name="Confirm_Password"
            value={vendor.Confirm_Password}
            onChange={onInputChange}
          />
          <span className="text-red-500">{vendorErrors.Confirm_Password}</span>
        </div>
        
        
        <button
          type="submit"
          className="w-full px-6 py-3 mt-6 text-sm font-medium tracking-wide text-white capitalize transition-colors duration-300 transform bg-blue-500 rounded-md hover:bg-blue-400 focus:outline-none focus:ring focus:ring-blue-300 focus:ring-opacity-50"
        >
          Register Vendor
        </button>

        {successMessage && <p className="text-green-500 mt-4">{successMessage}</p>}
        {errorMessage && <p className="text-red-500 mt-4">{errorMessage}</p>}
      </form>
    </section>
  );
};

export default VendorRegister;