import React from "react";
import { useState } from "react";
 
 
function PersonalInfo() {
    const [state, setState] = useState({
        Name: "",
        DoorNo: "",
        Street: "",
        LandMark: ""
    })
    function HandleInputChange(e) {
        const name = e.target.name
        const value = e.target.value
        setState({
            ...state,
            [name]: value
        })
    }
    return (
        <form>
           
 
            <div className="col-md-4">
                <div>
                   
                <center><h1> Personal Information </h1></center>
 
                <label for="name"> Name </label>
                <input name="name" type="text" className="form-control" id="name" value={state.name} onChange={HandleInputChange} />
                <label for="dno"> DoorNo </label>
                <input name="dno" type="text" className="form-control" id="dno" value={state.dno} onChange={HandleInputChange} />
                <label for="street"> Street </label>
                <input name="street" type="text" className="form-control" id="street" value={state.treet} onChange={HandleInputChange} />
                <label for="landMark"> Landmark</label>
                <input name="landMark" type="text" className="form-control" id="landMark" value={state.landMark} onChange={HandleInputChange} /><br />
                <button type="button" className="btn btn-primary" data-toggle="modal" data-target="#modalDialog">Submit</button>
</div>
            </div>
 
        </form>
    )
 
}
export default PersonalInfo