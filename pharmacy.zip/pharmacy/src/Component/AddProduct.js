import React from "react";
import Navbaradmin from "./Navbaradmin";
function AddProduct(){
return(
    <div>
        <Navbaradmin/>
        Addproducts
    </div>
)
}
 
export default AddProduct