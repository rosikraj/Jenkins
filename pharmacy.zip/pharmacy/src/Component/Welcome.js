import React from "react";
import MainNavbar from "./MainNavbar";

function Welcome(){
return(
    <div>
        <MainNavbar/>
        
        Welcome
    </div>
)
}
 
export default Welcome