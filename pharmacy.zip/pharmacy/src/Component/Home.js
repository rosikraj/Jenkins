import React from "react";
import Navbar from "./Navbar";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
 
function Home() {
    const [cartCount, setCartCount] = useState(0);
 
    const [buyCount, setBuyCount] = useState(0);
 
    const [viewCart, setViewCart] = useState([]);
 
    const [buyProduct, setBuyProducts] = useState([]);
 
    const [diffProduct, setDiffProduct] = useState({count:0,price:0})
   
    const [buyDiffProduct, setBuyDiffProduct] = useState({count:0,price:0})
 
    const navigate = useNavigate();
 
    function AddProductsCart(productId) {
        setCartCount(cartCount + 1);
        const product = Products.find(product=> product.productId==productId);
        const index = viewCart.findIndex(view=>view.productId == product.productId)
        if(index==-1) {
            viewCart.push(product)
        }
        else{
            setDiffProduct({count:diffProduct.count+1,price:diffProduct.price+product.productPrice})
        }
    }
    function RemoveProductsCart(productId) {
        if (cartCount > 0) {
            setCartCount(cartCount - 1);
            const index = Products.findIndex(product=>product.productId==productId);
            viewCart.splice(index,1);
        }
    }
    function AddProductsBuy(productId) {
        setBuyCount(buyCount + 1);
        const product = Products.find(product=> product.productId==productId);
        const index = buyProduct.findIndex(view=>view.productId == product.productId)
        if(index==-1) {
            buyProduct.push(product)
        }
        else{
            setBuyDiffProduct({count:buyDiffProduct.count+1,price:buyDiffProduct.price+product.productPrice})
        }
        console.log(buyDiffProduct)
    }
    function RemoveProductsBuy(productId) {
        if (buyCount > 0) {
            setBuyCount(buyCount - 1);
            const index = Products.findIndex(product=>product.productId==productId);
            buyProduct.splice(index,1);
        }
    }
    function AddToCart(productId) {
        const product = Products.find(product=> product.productId==productId);
        const index = viewCart.findIndex(view=>view.productId == product.productId)
        if(index==-1) {
            viewCart.push(product)
        }
        navigate("/cart",{state:{cart:viewCart, productDetails:diffProduct}})
    }
    function BuyProducts(productId) {
        const product = Products.find(product=> product.productId==productId);
        const index = buyProduct.findIndex(view=>view.productId == product.productId)
        if(index==-1) {
            buyProduct.push(product)
        }
        navigate("/buypage",{state:{buy:buyProduct, buydiffproductdetails:buyDiffProduct}})
    }
    return (
        <div>
            <Navbar cartItemsCount={cartCount} cartItems={viewCart} buyItemsCount={buyCount} buyPage={buyProduct} cartDetails={diffProduct} buyDetails={buyDiffProduct}/>  <br />
            <div className="row bg-primary-subtle">
                <div className="d-flex justify-content-end"></div>
                <div className="col-md-1"></div>
                {Products.map(product=>(
                    <div className="col">
                    <img src={product.url} style={{ height: "320px", width: "300px", className:"mx-5" }}/>
                   <div className="bg-primary">
                    <p className="mx-5" style={{ textAlign: "center", marginRight: "-10px" }}>Product_Id: {product.productId}</p>
                    <p className="mx-5" style={{ textAlign: "center", marginRight: "-10px" }}>Product_Name: {product.productProductName}</p>
                    <p className="mx-5" style={{ textAlign: "center", marginRight: "-10px" }}>Manufacture_Date: {product.productManufactureDate}</p>
                    <p className="mx-5" style={{ textAlign: "center", marginRight: "-10px" }}>Expiry_Date:{product.productExpDate}</p>
                    <p className="mx-5" style={{ textAlign: "center", marginRight: "-10px" }}>Price:{product.productPrice}</p>
                    <p className="mx-5" style={{ textAlign: "center", marginRight: "-10px" }}>Quantity:{product.productQuantity}</p>
                    <p className="mx-5" style={{ textAlign: "center", marginRight: "-10px" }}>Stock:{product.productPrice}</p>
                   </div>
                   
                    <div class="btn-group" role="group">
                        <button type="button" className="btn btn-danger rounded-circle" onClick={()=>{RemoveProductsCart(product.productId)}}>-</button>
                        <button type="button" className="btn btn-primary mx-1" onClick={()=>{AddToCart(product.productId)}}>Add Cart</button>
                        <button type="button" className="btn btn-success rounded-circle" onClick={()=>{AddProductsCart(product.productId)}}>+</button>
                    </div><br></br>
 
                    <div className="btn-group my-1" role="group">
                        <button type="button" class="btn btn-danger rounded-circle" onClick={()=>{RemoveProductsBuy(product.productId)}}>-</button>
                        <button type="button" class="btn btn-primary mx-1" onClick={()=>{BuyProducts(product.productId)}}>Buy</button>
                        <button type="button" class="btn btn-success rounded-circle" onClick={()=>{AddProductsBuy(product.productId)}}>+</button>
                    </div>
                </div>
                ))}
            </div>
        </div>
    )
}
export default Home
 
 
export const Products = [{
    productId:"1234",
    productName:"ASprin",
    productManufactureDate : "10/20/2023",
    productExpDate: "10/22/2024",
    productPrice: 20.00,
    productQuantity:2,
    productStock:234,
    url: "cp1.jpg"
},
{
    productId:"123884",
    productName:"Crocin",
    productManufactureDate : "11/20/2023",
    productExpDate: "10/22/2024",
    productPrice: 48.00,
    productQuantity:3,
    productStock:234,
    url: "cp1.jpg"
},
{
    productId:"127734",
    productName:"Citrezene",
    productManufactureDate : "11/20/2023",
    productExpDate: "10/22/2025",
    productPrice: 10.00,
    productQuantity:2,
    productStock:234,
    url: "cp1.jpg"
}]