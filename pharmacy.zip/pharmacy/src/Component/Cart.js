import React from "react";
import Navbar from "./Navbar";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
 
function Cart(){
    const location = useLocation();
    let cartItems = [];
    let cartDetails = {};
    let cost = 0;
    console.log(location.state && location.state?.productDetails)
    if(location.state?.cart && location.state?.productDetails) {
        cartItems = location.state.cart
        cartDetails = location.state.productDetails
        cost = cost + cartDetails.price
    }
 
    const [selectedProducts, setSelectedProducts] = useState(cartItems.length);
    // const [itemsCost, setItemsCount] = useState(0)
    // console.log(cartItems[0].url)
    const navigate = useNavigate();
 
    if(Object.keys(cartItems).length > 0) {
        for(let items of cartItems) {
            cost = cost + items.productPrice
        }
    }
    console.log(cartDetails)
   
    // setItemsCount(cost)
    // function AddSelectedProducts(productId) {
    //     const product = cartItems.find(product=> product.productId==productId);
    //     setSelectedProducts(selectedProducts + 1)
    //     cost = cost + product.productPrice
    //     console.log(product.productPrice, cost)
    //     // setItemsCount(product.productPrice + itemsCost)
    // }
    // function RemoveSelectedProducts(productId) {
    //     if(selectedProducts>0) {
    //         setSelectedProducts(selectedProducts-1)
    //         const product = cartItems.find(product=> product.productId==productId);
    //         cost = cost - product.productPrice
    //         // setItemsCount(product.productPrice - itemsCost)
    //     }
    // }
 
    function ProceedtoPay() {
        navigate("/PersonalInfo")
    }
return(
    <div>
        <Navbar/>
        <h4 style={{fontSize:"20px", color:"red"}}>Cart Items is </h4><br />
        {
            Object.keys(cartItems).length > 0 &&
            cartItems.map(items=>(
                    <>
                        <div className="row">
                            <div className="col-md-1"></div>
                            <div className="col-md-3 mx-2"> Product</div>
                            <div className="col-md-3 mx-2">Product id </div>
                            <div className="col-md-3 mx-2">Product Price</div>
                        </div>
                        <div className="row">
                            <div className="col-md-1"></div>
                            <div className="col-md-3">
                                <img src={items.url} style={{ height: "300px", width: "280px" }} />
                            </div>
                            <div className="col-md-3 mx-2 my-3">
                            {/* <button type="button" className="btn btn-danger rounded-circle" onClick={()=>{RemoveSelectedProducts(items.productId)}}>-</button>
                            // { <div> product quantity is {items.productQuantity} </div>}
                            <button type="button" className="btn btn-success rounded-circle" onClick={()=>{AddSelectedProducts(items.productId)}}>+</button> */}
                            <div> product id is {items.productId} </div>
                            </div>
                            <div className="col-md-3 mx-2 my-3">
                                {items.productPrice}
                            </div>
                        </div>
                    </>
                       
            ))
        }
        {cost > 0 && (
            <div className="row-md-6">
                <div className="col-md-6"></div>
                <div className="col-md-8">
                 <h1 className="row-md-9"> total cost is {cost} </h1>    
                </div>
                <div className="row">
                    <div className="col-md-6"></div>
                    <div className="col-md-6">
                        <button type="button" className="btn btn-primary" onClick={ProceedtoPay}>Proceed to Pay</button>
                    </div>
                </div>
            </div>
        )}
    </div>
)
}
export default Cart