import React from "react";
import Navbar from "./Navbar";
import { useLocation } from "react-router-dom";
 
 
function BuyPage(){
    const location = useLocation();
    let buyItems = [];
    let buyDiffProduct = {};
    let totalCost = 0;
    console.log(location.state)
    if(location.state?.buy && location.state?.buydiffproductdetails) {
        buyItems = location.state.buy
        buyDiffProduct = location.state.buydiffproductdetails
        totalCost = totalCost + buyDiffProduct.price
    }
    if(Object.keys(buyItems).length > 0) {
        for(let items of buyItems) {
            totalCost = totalCost + items.productPrice;
        }
    }
return(
    <div>
        <Navbar/>
        Buy
        {
            Object.keys(buyItems).length > 0 &&
            buyItems.map(items=>(
                <div>
                    <div className="row">
                        <div className="col-md-3">
                            <img src={items.url} style={{ height: "320px", width: "300px" }}/>
                        </div>
                        <div className="col-md-3">
                           {items.productQuantity}
                        </div>
                        <div className="col-md-3">
                            {items.productPrice}
                        </div>
                    </div>
                </div>
            ))
        }
        {totalCost > 0 && (
            <div>
                <div> total cost is {totalCost} </div>
            </div>
        )}
       
    </div>
)
}
 
export default BuyPage